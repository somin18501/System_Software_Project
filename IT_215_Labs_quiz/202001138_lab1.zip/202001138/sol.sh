#!bin/bash

# Q-1
touch abc.sh
chmod 755 abc.sh

# Q-2
lsb_release -a
uname -r

# Q-3
touch in1.txt
cat > in1.txt

touch in2.txt
cat > in2.txt

mkdir ../MyOut
touch ../MyOut/out.txt

cat in1.txt in2.txt >> ../MyOut/out.txt
cat ../MyOut/out.txt

# Q-4
grep "somin" in in1.txt in2.txt ../MyOut/out.txt

# Q-5
ls -ltr
ls -l | awk '{ x += $5 };END { print "total size in megabytes:"(x/1024/1024) }'

# Q-6
date
date  | cut -d ' ' -f 5-7