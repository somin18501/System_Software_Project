#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <math.h>

int ptable[5][3];
pthread_mutex_t mutex;
pthread_rwlock_t rwmutex;

void *writer(){
    int proid=(rand()+1)%10;
    int pg=(rand()+50)%1000;
    int freq=1;

    pthread_rwlock_wrlock(&rwmutex);
    for(int i=1;i<5;i++){
        int tp1=ptable[i][2],tp2=ptable[i][1],tp3=ptable[i][0],j=i-1;
        while(j>=0 && tp1<ptable[j][2]){
            ptable[j+1][2]=ptable[j][2];
            ptable[j+1][1]=ptable[j][1];
            ptable[j+1][0]=ptable[j][0];
            j--;
        }
        ptable[j+1][2]=tp1;
        ptable[j+1][1]=tp2;
        ptable[j+1][0]=tp3;
    }

    ptable[0][0]=proid;
    ptable[0][1]=pg;
    ptable[0][2]=freq;
    for(int i=0;i<5;i++){
        for(int j=0;j<3;j++){
            printf("%d ",ptable[i][j]);
        }
        printf("\n");
    }
    printf("writer: %lu\n",pthread_self());
    pthread_rwlock_unlock(&rwmutex);
}

void *reader(){
    int proid=(rand()+1)%10;
    pthread_rwlock_rdlock(&rwmutex);
    for(int i=0;i<5;i++){
        if(ptable[i][0]==proid){
            pthread_mutex_lock(&mutex);
            ptable[i][2]++;
            pthread_mutex_unlock(&mutex);
        }
    }
    for(int i=0;i<5;i++){
        for(int j=0;j<3;j++){
            printf("%d ",ptable[i][j]);
        }
        printf("\n");
    }
    printf("reader: %lu\n",pthread_self());
    pthread_rwlock_unlock(&rwmutex);
}

int main(){
    memset(ptable, -1, sizeof(ptable));

    int ret=pthread_mutex_init(&mutex,NULL);
    int ret2=pthread_rwlock_init(&rwmutex,NULL);
    pthread_t threadid[20];

    for(int i=0;i<20;i++){
        if(i%2==0){
            pthread_create(&threadid[i],NULL,writer,NULL);
        }
        else{
            pthread_create(&threadid[i],NULL,reader,NULL);
        }
    }

    for(int i=0;i<20;i++){
        pthread_join(threadid[i],NULL);
    }

    printf("<--Final ptable Entries-->\n");
    for(int i=0;i<5;i++){
        for(int j=0;j<3;j++){
            printf("%d ",ptable[i][j]);
        }
        printf("\n");
    }

    ret=pthread_mutex_destroy(&mutex);
    ret2=pthread_rwlock_destroy(&rwmutex);

    return 0;
}
