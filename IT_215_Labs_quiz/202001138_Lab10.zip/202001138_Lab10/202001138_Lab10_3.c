#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <math.h>
#include <semaphore.h>

int ptable[5][3];
sem_t semaphore[5];

void *writer()
{
    int proid = (rand() + 1) % 10;
    int pg = (rand() + 50) % 1000;
    int freq = 1;
    for (int i = 0; i < 5; i++)
        sem_wait(&semaphore[i]);

    for (int i = 1; i < 5; i++)
    {
        int tp1 = ptable[i][2], tp2 = ptable[i][1], tp3 = ptable[i][0], j = i - 1;
        while (j >= 0 && tp1 < ptable[j][2])
        {
            ptable[j + 1][2] = ptable[j][2];
            ptable[j + 1][1] = ptable[j][1];
            ptable[j + 1][0] = ptable[j][0];
            j--;
        }
        ptable[j + 1][2] = tp1;
        ptable[j + 1][1] = tp2;
        ptable[j + 1][0] = tp3;
    }

    ptable[0][0] = proid;
    ptable[0][1] = pg;
    ptable[0][2] = freq;

    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf("%d ", ptable[i][j]);
        }
        printf("\n");
    }
    printf("writer: %lu\n",pthread_self());
    for (int i = 0; i < 5; i++)
        sem_post(&semaphore[i]);
}

void *reader()
{
    int proid = (rand() + 1) % 10;

    for (int i = 0; i < 5; i++)
    {
        if (ptable[i][0] == proid)
        {
            sem_wait(&semaphore[i]);
            ptable[i][2]++;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    printf("%d ", ptable[i][j]);
                }
                printf("\n");
            }
            printf("reader: %lu\n",pthread_self());
            sem_post(&semaphore[i]);
        }
    }
}

int main()
{
    memset(ptable, -1, sizeof(ptable));

    for(int i=0;i<5;i++)
        sem_init(&semaphore[i], 0, 1);
    

    pthread_t threadid[20];

    for (int i = 0; i < 20; i++)
    {
        if (i % 2 == 0)
        {
            pthread_create(&threadid[i], NULL, writer, NULL);
        }
        else
        {
            pthread_create(&threadid[i], NULL, reader, NULL);
        }
    }

    for (int i = 0; i < 20; i++)
    {
        pthread_join(threadid[i], NULL);
    }

    printf("<--Final ptable Entries-->\n");
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf("%d ", ptable[i][j]);
        }
        printf("\n");
    }

    for(int i=0;i<5;i++)
        sem_destroy(&semaphore[i]);

    return 0;
}
