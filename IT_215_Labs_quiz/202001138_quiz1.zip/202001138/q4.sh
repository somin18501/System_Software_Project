# !bin/bash

echo -e "enter the path: \c"
read name
if [ -f $name ] # -e for file existance , -f for regular file existance , -d is for directory , -c for file with only text , -b for file with pictures
then                 # -s to check wheather file is empty or not , -r/-w/-x to check read/write/execute permissions 
    echo "$name FOUND and it is a FILE"
elif [ -d $name ]
then 
    echo "$name FOUND and it is a DIRECTORY"
else
    echo "$name this PATH do not exist"
fi