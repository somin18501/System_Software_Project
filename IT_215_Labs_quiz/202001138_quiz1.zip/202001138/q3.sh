# !bin/bash

select item in {1..7}
do
    case $item in
        1 )
            echo "day $item of week is SUNDAY" ;;
        2 )
            echo "day $item of week is MONDAY" ;;
        3 )
            echo "day $item of week is TUESDAY" ;;
        4 )
            echo "day $item of week is WEDNESSDAY" ;;
        5 )
            echo "day $item of week is THURSDAY" ;;
        6 )
            echo "day $item of week is FRIDAY" ;;
        7 )
            echo "day $item of week is SATURDAY" ;;
        * )
            echo "enter VALID option"
    esac
done