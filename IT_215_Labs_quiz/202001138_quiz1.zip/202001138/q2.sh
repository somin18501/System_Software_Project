# !bin/bash

# only way for recursion
fact() {
    if [ $1 -lt 2 ]
    then 
        echo 1
    else
        req=$(( $1 - 1 )) 
        res=$( fact $req )
        echo $(( $1 * res ))
    fi
}
echo "$1! is $(fact $1)"