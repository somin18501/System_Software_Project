# !bin/bash

sum=0
for item in $*
do
    sum=$(( sum + $item ))
done
echo "Sum of command line arguments integers is $sum"
# echo $@