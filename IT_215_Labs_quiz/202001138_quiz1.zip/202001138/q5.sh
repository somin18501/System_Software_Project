# !bin/bash

echo -e "enter the path of logs folder: \c"
read name
grep "warning" $name/*.log >> warning.log