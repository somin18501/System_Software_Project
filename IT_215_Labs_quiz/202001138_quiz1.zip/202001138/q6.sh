# !bin/bash

echo -e "enter the path of folder: \c"
read name
i=0
for fl in $(ls -t -r $name)
do
    echo "processing file $fl"
    $name/$fl $*
    arr[i]=$?
    i=$(( i + 1 ))
done
echo "${arr[@]}"

