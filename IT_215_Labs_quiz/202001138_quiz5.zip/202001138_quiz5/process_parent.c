#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main( int argc, char* argv[] )
{
	if (argc < 6)
	{
		printf("USAGE: parent_process.out <num1> <num2> ...");
	}
	int i, childPID, status;
	for(i=0; i<argc-1; i=i+1)
	{	
		if ( fork() == 0 )
		{
			printf("Child with PID=%d started\n",getpid());
			printf("File name: %s\n", argv[i+1]);
			printf("%s,%s,%s\n","No. of lines","words","bytes are:");
			execl( "./process_child.out","./process_child.out",argv[i+1], NULL); 
			fprintf( stderr, "Could not execute %s \n", argv[i+1] );
		}
		else
		{
			childPID = wait(&status);
			printf("Child with PID=%d finished\n\n", childPID);
		}
	}
}