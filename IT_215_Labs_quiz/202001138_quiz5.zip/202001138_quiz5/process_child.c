#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

void main(int argc, char* argv[])
{
	char s[]="wc -l -w -c ";
	strcat(s,argv[1]);
	system(s);
	exit(1);
}