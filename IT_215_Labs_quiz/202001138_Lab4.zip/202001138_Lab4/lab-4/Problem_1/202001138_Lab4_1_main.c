#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"202001138_Lab4_1_myheader.h"

int main(){
    float ans=0,n;
    printf("Enter angle in degree: ");
    scanf("%f",&n);
    int x=1;
    n*=(3.1415/180);
    for(int i=1;i<6;i++){
        if(i%2==0){
            ans-=((float)mypow(n,x)/myfact(x));
        }
        else{
            ans+=((float)mypow(n,x)/myfact(x));
        }
        x+=2;
    }
    printf("my answer of sin(%f) = %f\n",n*180/3.1415,ans);
    return 0;
}