int myfact(int n){
    int pro=1;
    for(int i=2;i<=n;i++){
        pro*=i;
    }
    return pro;
}