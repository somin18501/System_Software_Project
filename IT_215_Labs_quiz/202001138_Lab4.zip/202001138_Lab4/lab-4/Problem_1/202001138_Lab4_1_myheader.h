int myfact(int n);
float mypow(float n,int x);