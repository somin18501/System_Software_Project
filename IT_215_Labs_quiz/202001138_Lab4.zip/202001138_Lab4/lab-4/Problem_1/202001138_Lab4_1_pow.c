float mypow(float n,int x){
    if(x==1) return n;
    if(x%2==0){
        return mypow(n,x/2)*mypow(n,x/2);
    }
    else{
        return mypow(n,x/2)*mypow(n,x/2)*n;
    }
}