#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"func_call.h"

int Isdigit(char ch);
int check_prime3(int num);

int main(int argc, char *argv[]){
    char ch=7;
    int num=23;
    printf("The result of digit check is: %d\n",Isdigit(ch));
    printf("The result of prime check is: %d\n",check_prime3(num));
    return 0;
}