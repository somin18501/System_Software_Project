// int Isdigit(char ch);
// int check_prime3(int num);
void Print();