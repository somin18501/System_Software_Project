int Isdigit(char ch){
    if(ch>=48 && ch<=57) return 1;
    return 0;
}