#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main( int argc, char* argv[] )
{
	if (argc < 3)
	{
		printf("USAGE: 202001138_Lab6_1_expo_parent.out <num1> <num2>");
	}
	int childPID, status, pid;
    printf("I am the original process with PID %d and PPID %d\n", getpid(), getppid());
    pid = fork();
	if ( pid == 0 )
	{
		printf("Child with PID=%d started\n",getpid());
		execl( "./202001138_Lab6_1_expo_child.out","./202001138_Lab6_1_expo_child.out",argv[1],argv[2], NULL); 
		fprintf( stderr, "Could not execute %s \n", argv[0]);
	}
	else
	{
		childPID = wait(&status);
		printf("child with PID %d finished\n", childPID);
        if WIFEXITED(status)
			printf("child with PID %d has terminated normally with value of e = %d\n", childPID, WEXITSTATUS(status));
		else if WIFSIGNALED(status)
			printf("child with PID %d was terminated by signal %d\n", childPID, WTERMSIG(status));
		else
			printf("child with PID %d had abnormal termination\n", childPID);
        printf("parent process with PID %d : done\n", getpid());
	}
}