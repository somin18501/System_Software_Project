#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

int myfact(int n){
    int pro=1;
    for(int i=2;i<=n;i++){
        pro*=i;
    }
    return pro;
}

float mypow(float n,int x){
    float ans=1;
    for(int i=1;i<=x;i++){
        ans*=n;
    }
    return ans;
}

void main(int argc, char* argv[]){
    printf("child pid = %d got x = %s, n = %s\n", getpid(), argv[1], argv[2]);
	float ans=0,x;
    int n;
    x=atof(argv[1]);
    n=atoi(argv[2]);
    // if(x>=1 || n<1){
    //     printf("child process with PID %d : for x = %f and n = %d\n",getpid(),x,n);
    //     exit(0);
    // } 
    for(int i=0;i<n;i++){
        ans+=((float)mypow(x,i)/myfact(i));
    }
    printf("child process with PID %d : for x = %f the first %d terms yield %f\n",getpid(),x,n,ans);
    exit(ans);
}