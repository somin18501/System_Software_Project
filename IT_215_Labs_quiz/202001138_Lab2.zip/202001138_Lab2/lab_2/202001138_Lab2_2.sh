# !bin/bash

count() {
    dir=$1
    if [ -d $dir ]
    then
        c=$2
        for item in $(ls -R $dir)
        do 
            if [ -d $dir/$item ]
            then
                req=$dir/$item
                res=$( count $req $c )
                c=$res
            elif [ -f $dir/$item ]
            then 
                c=$(( c + 1 ))
            fi
        done
        echo $c
    elif [ -f $dir ]
    then 
        echo "GIVEN PATH IS OF FILE $1"
    else
        echo "NOT SUCH DIRECTORY FOUND"
    fi
}
k=0
echo "TOTAL FILES IN DIRECTORY $1 IS $(count $1 $k)"
# NOTE: it do not count pdf as file where as zip is considered as a file