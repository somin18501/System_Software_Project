# !bin/bash

rmduplicate() {
    dir=$1
    if [ -f $dir ]
    then
        sort $dir | uniq > distinct.txt 
    else    
        echo "THE PATH $dir IS NOT OF A txt FILE"
    fi
}
rmduplicate $1