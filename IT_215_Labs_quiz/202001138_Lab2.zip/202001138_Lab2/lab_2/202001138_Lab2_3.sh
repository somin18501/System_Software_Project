# !bin/bash

remove() {
    dir=$1
    if [ -d $dir ]
    then
        for item in $(ls -R $dir)
        do 
            if [ -d $dir/$item ]
            then
                req=$dir/$item
                if [ "$(ls -A $req)" ]
                then
                    res=$( remove $req )
                    echo $res
                else
                    echo "$req DELETED SUCCESSFULLY"
                    rmdir $dir/$item
                fi
            fi
        done
    elif [ -f $dir ]
    then 
        echo "GIVEN PATH IS OF FILE $1"
    else
        echo "NOT SUCH DIRECTORY FOUND"
    fi
}
remove $1