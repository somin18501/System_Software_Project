# !bin/bash

# sum=0
# for i in {1..9}
# do
#     echo -e "enter the integer $i: \c"
#     read num
#     sum=$(( sum + num ))
# done
# echo "The total of all num is: $sum"

sum=0
if [ $# -gt 9 ]
then
    echo "INPUT SIZE EXCEEDS 9"
else
    for i in $*
    do 
        sum=$(( sum + $i ))
    done
    echo "The total of all numbers is: $sum"
fi