#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char* argv[])
{
	char* file_name=argv[1];
	int line=atoi(argv[2]);
	FILE* file=fopen(file_name,"r");
	char buff[256]; /* universal length of a line is 256 bytes */
	int i=0;
	while(fgets(buff,sizeof(buff),file))
	{
		if(i+1==line)
		{
			printf("%s",buff);
		}
		i++;
	}
	fclose(file);
	return 0;
}
