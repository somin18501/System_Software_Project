#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#define READ 0
#define WRITE 1

char* questions[] = {"quit", "You study in which university?", "which course are you studying?", "what is your area of interest?"};
char* answers[] = {"quit", "DAIICT", "Systems Programming", "Embedded Systems"};

int main()
{
	int byteread;
	int fd1[2],fd2[2],status;
	char msg[100];
	pipe(fd1); /* pipe for parent to child */
	pipe(fd2); /* pipe for child to parent */
	if(fork()==0)/*child*/
	{
		close(fd1[WRITE]);
		close(fd2[READ]);
		while(1)
		{
			byteread=read(fd1[READ],msg,100);
			int i;
			for(i=0;i<4;i++)
			{
				if(strcmp(msg,questions[i])==0)
				{
					break;
				}
			}
			write(fd2[WRITE],answers[i],strlen(answers[i])+1);
			if(strcmp(msg,answers[0])==0) break;
		}
		close(fd1[READ]);
		close(fd2[WRITE]);
	}
	else/*parent*/
	{
		close(fd1[READ]);
		close(fd2[WRITE]);
		while(strcmp(msg,answers[0])!=0)
		{
			int num;
			printf("Enter number:");
			scanf("%d",&num);
			printf("PARENT: %s\n",questions[num]);
			write(fd1[WRITE],questions[num],strlen(questions[num])+1);
			byteread=read(fd2[READ],msg,100);
			if(strcmp(msg,answers[0])!=0)
			{
				printf("CHILD:%s\n",msg);
			}
		}
		close(fd1[WRITE]);
		close(fd2[READ]);
		wait(&status);
	}
	return 0;
}

