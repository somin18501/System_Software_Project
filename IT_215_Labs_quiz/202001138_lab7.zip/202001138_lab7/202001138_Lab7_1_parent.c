#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define READ 0
#define WRITE 1

int main(int argc,char* argv[])
{
	int fd[2],byteread,status;
	char buff[256];
	pipe(fd); /* create unnamed pipe */
	if(fork()==0)	/*child process*/
	{
		close(fd[READ]); /* as child is writter so its read end is closed */
		dup2( fd[WRITE], 1); /* diverting stdout to write end of pipe */
		close(fd[WRITE]); /* closing write end as now stdout is writer */
		execlp("./202001138_Lab7_1_child.out","./202001138_Lab7_1_child.out",argv[1],argv[2],NULL);
	}
	else /*parent process*/
	{
		close(fd[WRITE]); /* as parent is reader so its write end is closed */
		byteread= read( fd[READ], buff, 256);
		printf("%d line of %s:\n%s",atoi(argv[2]),argv[1],buff);
		wait(&status);
		close(fd[READ]);
	}
	return 0;
}
