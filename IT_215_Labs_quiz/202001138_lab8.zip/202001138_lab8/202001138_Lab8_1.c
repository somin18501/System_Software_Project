#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void alarmHandler();	/* Forward declaration of alarm handler */
int main(void)
{
    char ip[100];
	signal( SIGALRM, alarmHandler );	/* Install signal handler */
	printf("Enter the input string:");
    alarm(10);	/* Schedule an alarm signal in ten seconds */
    scanf("%[^\n]s",ip);
	exit(0);
}

void alarmHandler() 
{
	printf("\nit took too long to enter the string\n");
	exit(-1);
}