#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

int main(void)
{
    int proid,op;
    printf("Enter process id: ");
    scanf("%d",&proid);
    printf("Enter 1 for killing process\n");
    printf("Enter 2 for killing entire group\n");
    scanf("%d",&op);
    if(op==1){
        kill(proid,SIGINT);
    }
    else{
        kill(-proid,SIGINT);
    }
    return 0;
}
