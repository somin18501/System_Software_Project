#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define READ 0
#define WRITE 1

char *questions[] = {"quit", "You study in which university?", "which course are you studying?", "what is your area of interest?"};
char *answers[] = {"quit", "DAIICT", "Systems Programming", "Embedded Systems"};

static void signal_handler(int);
int i, pid1, pid2, status;

int byteread;
int fd1[2], fd2[2], status;
char msg[100];

int main()
{
	int exit_status;
	pipe(fd1); /* pipe for parent to child */
	pipe(fd2); /* pipe for child to parent */
	if (signal(SIGUSR1, signal_handler) == SIG_ERR)
	{
		printf("P�rent: Unable to create handler for SIGUSR1\n");
	}

	if (signal(SIGUSR2, signal_handler) == SIG_ERR)
	{
		printf("P�rent: Unable to create handler for SIGUSR2\n");
	}

	pid1 = getpid();

	if ((pid2 = fork()) == 0)
	{
		for (;;)
			; /* loop forever */
	}
	else
	{
		int num;
		printf("Enter number:");
		scanf("%d", &num);
		close(fd1[READ]);
		close(fd2[WRITE]);
		printf("PARENT: %s\n", questions[num]);
		write(fd1[WRITE], questions[num], strlen(questions[num]) + 1);
		kill(pid2, SIGUSR1);
		wait(&status);
		close(fd1[WRITE]);
		close(fd2[READ]);
		kill(pid1, SIGINT);
	}
	return 0;
}

static void signal_handler(int signo)
{
	/* signo contains the signal number that was received */
	switch (signo)
	{
	/* Signal is a SIGUSR1 */
	case SIGUSR1:
		printf("Child Process (%d): received SIGUSR1 \n", getpid());
		if (pid1 != getpid()) /* it is the child */
		{
			close(fd1[WRITE]);
			close(fd2[READ]);
			byteread = read(fd1[READ], msg, 100);
			int i;
			for (i = 0; i < 4; i++)
			{
				if (strcmp(msg, questions[i]) == 0)
				{
					break;
				}
			}
			write(fd2[WRITE], answers[i], strlen(answers[i]) + 1);
			if (strcmp(msg, answers[0]) == 0)
			{
				close(fd1[READ]);
				close(fd2[WRITE]);
				printf("CHILD:%s\n", msg);
				kill(pid2, SIGINT);
			}
			printf("Child Process (%d) is passing SIGUSR2 to Parent Process(%d)...\n", getpid(), pid1);
			kill(pid1, SIGUSR2);
		}
		break;
	/*  It's a SIGUSR2 */
	case SIGUSR2:
		printf("Parent Process (%d): received SIGUSR2 \n", getpid());
		if (pid1 == getpid())
		{
			byteread = read(fd2[READ], msg, 100);
			if (strcmp(msg, answers[0]) != 0)
			{
				printf("CHILD:%s\n", msg);
			}
			int num;
			printf("Enter number:");
			scanf("%d", &num);
			printf("PARENT: %s\n", questions[num]);
			write(fd1[WRITE], questions[num], strlen(questions[num]) + 1);
			printf("Parent Process (%d) is passing SIGUSR2 to Child Process(%d)...\n", getpid(), pid2);
			kill(pid2, SIGUSR1);
		}
		break;
	default:
		break;
	}
	return;
}
