#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void signalHandler();	/* Forward declaration of alarm handler */
int main(void)
{
    int status;
	signal( SIGINT, signalHandler );	/* Install signal handler */
    if(fork()==0){
        setpgid(0,0);
        printf("Its process id is %d and process group id is %d\n",getpid(),getpgid(0));
        while(1);
    }
    else{
        printf("Its process id is %d and process group id is %d\n",getpid(),getpgid(0));
        while(1);
    }
    return 0;
}

void signalHandler() 
{
	printf("Process id %d received SIGINT signal\n",getpid());
    exit(0);
}