# !bin/bash
ln $1 original_hard2
ln -s $1 original_soft2