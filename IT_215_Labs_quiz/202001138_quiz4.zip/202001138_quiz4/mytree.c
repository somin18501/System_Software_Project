#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>

void printtree(char *dname,int tabcounter)
{
	DIR *dir_ptr; /* the directory */
	struct dirent *direntp; /* each entry! */
	dir_ptr = opendir( dname );
	chdir(dname);
	if ( dir_ptr == NULL ){
		fprintf(stderr, "cannot open a directory\n");
		exit(1);
	}

	while ( ( direntp = readdir(dir_ptr) ) != NULL ){
		if(!strcmp(direntp->d_name,".") || !strcmp(direntp->d_name,"..")) continue;
		for(int i=0;i<tabcounter-1;i++) printf("	");
		printf("└──%s\n",direntp->d_name);
		struct stat st;
		stat(direntp->d_name, &st);
		if (S_ISDIR(st.st_mode))
		{
			tabcounter++;
			printtree(direntp->d_name,tabcounter);
			tabcounter--;
		}
	}
	chdir(".."); 
	closedir( dir_ptr );
	return;
}

int main(int argc, char *argv[])
{
	if (argc < 2)
	{
		fprintf(stderr, "USAGE: stat_example.out file_or_dir_with_path\n");
		exit(1);
	}
	printf("%s\n",argv[1]);
	printtree(argv[1],1);
}
