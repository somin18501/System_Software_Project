#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(){
    char existingpath[100],newpath[100];
    struct stat st1,st2,st3;
    printf("Enter the file path who's hardlink/softlink is to be created:");
    gets(existingpath);
    stat(existingpath, &st1);
    printf("original file %s has inode %d\n", existingpath, st1.st_ino);
    printf("Enter the new file path for naming hardlink:");
    gets(newpath);
    link(existingpath,newpath);
    lstat(newpath, &st2);
    printf("hardlink %s has inode %d\n", newpath, st2.st_ino);
    printf("Enter the new file path for naming softlink:");
    gets(newpath);
    symlink(existingpath,newpath);
    lstat(newpath, &st3);
    printf("softlink %s has inode %d\n", newpath, st3.st_ino);
    return 0;
}
