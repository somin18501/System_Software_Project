#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>

void mycat(const char *pathname){
    FILE *fp=fopen(pathname,"r");
    int bufsize = 1024;
	char buf[bufsize];
	while (fgets(buf, bufsize, fp) != NULL){
    	fputs(buf, stdout);
    }
    fclose(fp);
}

void myls(const char *pathname){
    DIR *dir_ptr; /* the directory */
	struct dirent *direntp; /* each entry! */
	dir_ptr = opendir( pathname );
	chdir(pathname);
	if ( dir_ptr == NULL ){
		fprintf(stderr, "cannot open a directory\n");
		exit(1);
	}

	while ( ( direntp = readdir(dir_ptr) ) != NULL ){
		if(!strcmp(direntp->d_name,".") || !strcmp(direntp->d_name,"..")) continue;
		printf("    %s\n",direntp->d_name);
	}
	chdir(".."); 
	closedir( dir_ptr );
	return;
}

void mymv(const char *filename,char *destiny){
    struct stat st;
	stat(destiny, &st);
    int bufsize = 1024;
	char buf[bufsize];
    if (S_ISDIR(st.st_mode)){
        char p[100];
        int k=strlen(filename),i,c=0;
        for(i=k-1;filename[i]!='/';i--){
            p[k-i-1]=filename[i];
            c++;
        }
        p[c]='/';
        int l=0,h=strlen(p)-1;
        while(l<h){
            char tp=p[l];
            p[l]=p[h];
            p[h]=tp;
            l++;
            h--;
        }
        strcat(destiny,p);
		FILE *fp=fopen(filename,"r");
        FILE *fp1=fopen(destiny,"a");
        while (fgets(buf, bufsize, fp) != NULL){
            fputs(buf,fp1);
        }
        remove(filename);
	}
    else{
        int val=rename(filename,destiny);
        if(val!=0){
            FILE *fp=fopen(filename,"r");
            FILE *fp1=fopen(destiny,"a");
            while (fgets(buf, bufsize, fp) != NULL){
                fputs(buf,fp1);
            }
            remove(filename);
        }
    }
}

int main(int argc, char *argv[]){
    // if (argc < 2)
	// {
	// 	fprintf(stderr, "USAGE: stat_example.out file_or_dir_with_path\n");
	// 	exit(1);
	// }
    // mycat(argv[1]);
    // printf("%s\n",argv[1]);
    // myls(argv[1]);
    mymv(argv[1],argv[2]);
    return 0;
}
