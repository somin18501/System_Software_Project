#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int recursive_strlen(char *str){
    char tmp=*str;
    if(tmp=='\0') return 0;
    str++;
    return 1+recursive_strlen(str);
}

int main(){
    char arr[100];
    printf("Enter your string: ");
    gets(arr);
    printf("the length of given string is: %d\n",recursive_strlen(arr));
    return 0;
}