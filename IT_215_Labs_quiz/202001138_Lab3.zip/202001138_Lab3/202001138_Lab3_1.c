#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

long long fib(int n){
    int c1=0,c2=1,t=0;
    for(int i=2;i<n;i++){
        t=c1+c2;
        c1=c2;
        c2=t;
    }
    if(n==0) return c1;
    else if(n==1) return c2;
    return t;
}

long long fac(int n){
    int pro=1;
    for(int i=1;i<=n;i++){
        pro*=i;
    }
    return pro;
}

long long numlen(int n){
    return floor(log10(n)+1);
}

int main(int argc, char* argv[]){
    long long (*fns[3])(int n) = {fib, fac, numlen};
	int x;
	int ch;
	while (1){
		printf("1 for fibonacci\n");
		printf("2 for factorial\n");
		printf("3 for number length\n");
		printf("0 for Exit\n");
		printf("Enter operation to perform: ");
		scanf("%d", &ch);
		if (ch<0 || ch>3){
			printf("%d invalid option\n", ch);
		}
        else if(ch==0) break; 
		else{
			printf("Enter the number:");
			scanf("%d", &x);
			long long result = fns[ch-1](x);
			printf("answer is: %lld\n",result);
		}
	}
    return 0;
}