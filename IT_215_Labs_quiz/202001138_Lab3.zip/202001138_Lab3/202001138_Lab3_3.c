#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>

struct program{
    int prog_id;
    char prog_name[50];
    char uid_executing[25];
    int prog_status;
    float start_time;
    float time_elapsed;
    struct program *prev;
    struct program *next;
};

struct program *head = NULL;
struct program *last = NULL;

void add_new_entry(){
    static int id=0;
    struct program *tmp=(struct program *)malloc(sizeof(struct program));
    tmp->prog_id=20220000+id;
    tmp->prog_status=-1;
    tmp->time_elapsed=0;
    tmp->start_time=0;
    tmp->prev=NULL;
    tmp->next=NULL;
    printf("enter program name: ");
    scanf("%s",tmp->prog_name);
    printf("enter user id name: ");
    scanf("%s",tmp->uid_executing);
    id++;
    if(head==NULL){
        head=tmp;
        last=tmp;
    }
    else{
        tmp->prev=last;
        last->next=tmp;
        last=tmp;
    }
}

void start_query(int qid){
    struct program *n1;
    n1=head;
    while(n1){
        if(n1->prog_id==qid){
            if(n1->prog_status==-1){
                n1->prog_status=0;
                n1->start_time=clock();
            }
            else printf("program is already started or finished\n");
            break;
        }
        n1=n1->next;
    }
    if(n1==NULL) printf("NO such program id exist\n");
}

void update_time(){
    struct program *n1;
    n1=head;
    while(n1){
        if(n1->prog_status==0){
            n1->time_elapsed=clock()-(n1->start_time);
        }
        n1=n1->next;
    } 
}

void finish_query(int qid){
    struct program *n1;
    n1=head;
    while(n1){
        if(n1->prog_id==qid){
            if(n1->prog_status==0){
                n1->prog_status=1;
                n1->time_elapsed=clock()-(n1->start_time);
            }
            else printf("program is already finished or not started\n");
            break;
        }
        n1=n1->next;
    }
    if(n1==NULL) printf("NO such program id exist\n");
}

void Remove(){
    while(head!=NULL && head->prog_status==1){
        head=head->next;
        head->prev=NULL;
    }
    if(head!=NULL){
        struct program *n1;
        n1=head->next;
        while(n1){
            if(n1->prog_status==1){
                n1->prev->next=n1->next;
                if(n1->next==NULL){
                    last=n1->prev;
                }
                else{
                    n1->next->prev=n1->prev;
                }
            }
            n1=n1->next;
        }
    }
    else{
        printf("program table is empty\n");
    }
}

void printtable(){
    struct program *n1;
    n1=head;
    while(n1){
        printf("program_id: %d\n",n1->prog_id);
        printf("program name: %s\n",n1->prog_name);
        printf("user id name: %s\n",n1->uid_executing);
        if(n1->prog_status==-1) printf("status: submitted\n");
        else if(n1->prog_status==0) printf("status: running\n");
        else printf("status: completed\n");
        printf("start time: %f micro secs\n",n1->start_time);
        printf("time_elapsed: %f micro secs\n",n1->time_elapsed);
        printf("\n");
        n1=n1->next;
    }
}

int main(){
    while(1){
        int option,qid;
        printf("Enter 1 to add new query               Enter 2 to start query                    Enter 3 to update time elapsed\n");
        printf("Enter 4 to finish the query            Enter 5 to remove the query               Enter 6 to view all queries\n");
        printf("Enter 0 to exit\n");
        printf("Enter the option no. from below list to modify queries: ");
        scanf("%d",&option);
        switch (option){
        case 1:
            add_new_entry();
            printf("\n");
            printtable();
            break;
        case 2:
            printf("Enter program id that is to be started: ");
            scanf("%d",&qid);
            printf("\n");
            start_query(qid);
            printf("\n");
            printtable();
            break;
        case 3:
            printf("\n");
            update_time();
            printf("\n");
            printtable();
            break;
        case 4:
            printf("Enter program id that is to be finished: ");
            scanf("%d",&qid);
            printf("\n");
            finish_query(qid);
            printf("\n");
            printtable();
            break;
        case 5:
            printf("\n");
            Remove();
            printf("\n");
            printtable();
            break;
        case 6:
            printf("\n");
            printtable();
            break;
        case 0:
            printf("You are exited\n");
            break;
        default:
            printf("INVALID OPTION\n");
            break;
        }
        if(option==0) break;
    }
    return 0;
}