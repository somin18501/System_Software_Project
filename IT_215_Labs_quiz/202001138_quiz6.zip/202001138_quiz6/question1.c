#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#define READ 0
#define WRITE 1

struct node{
    int query_id;
    char qry_txt[50];
};

int main()
{
    int byteread;
	int fd1[2],fd2[2],status;
	char msg[56];
	pipe(fd1); /* pipe for parent to child */
	pipe(fd2); /* pipe for child to parent */
	if(fork()==0)/*child*/
	{
		close(fd1[WRITE]);
		close(fd2[READ]);
		while(1)
		{
			byteread=read(fd1[READ],msg,56);
            printf("query is : %s\n",msg);
			write(fd2[WRITE],"@",1+1); // acknowlegdgement
		}
		close(fd1[READ]);
		close(fd2[WRITE]);
	}
	else/*parent*/
	{
		close(fd1[READ]);
		close(fd2[WRITE]);
		while(1)
        {
            int id,idc,count=0;
            char str[50];
            printf("Enter the id:");
            scanf("%d",&id);
            idc=id;
            printf("Enter the text:");
            scanf(" %[^\n]s",str);
            struct node* new=(struct node*)malloc(sizeof(struct node));
            new->query_id=id;
            strcpy(new->qry_txt,str);
            char buf[56]={'0','0','0','0','0','\0'};
            int i=4;
            while(idc!=0)
            {
                buf[i]=idc%10+'0';
                idc=idc/10;
                i--;
            }
            strcat(buf," ");
            strcat(buf,str);
            write(fd1[WRITE],buf,strlen(buf)+1);
            byteread=read(fd2[READ],msg,2);
            printf("Acknowledge recieved!!!\n");
        }
		close(fd1[WRITE]);
		close(fd2[READ]);
	}
	return 0;
}