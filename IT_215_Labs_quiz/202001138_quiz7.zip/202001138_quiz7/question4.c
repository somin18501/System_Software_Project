#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int p, pc1, pc2;

void childhandler()
{
    int status;
    printf("Child 2: Id-%d is  killed and parent is also killed now\n", wait(&status));
    kill(getpid(), SIGINT);
}
void alarmHandler()
{
    printf("child 2: Id-%d is resumed after 7sec\n",pc2);
    kill(pc2, SIGCONT);
    signal(SIGCHLD, childhandler);
    kill(pc2, SIGINT);
    pause();
}
void test()
{
    int status;
    printf("Child 1: Id-%d is killed after 4sec\n",pc1);
    kill(pc1, SIGINT);
    printf("Child 1: Id-%d is  killed\n", wait(&status));
    alarm(3);
    signal(SIGALRM, alarmHandler);
}
void suspend()
{
    printf("child 2: Id-%d is suspended after 2sec\n",pc2);
    kill(pc2, SIGSTOP);
    alarm(2);
    signal(SIGALRM, test);
}
int main()
{
    p = getpid();
    printf("Parent Process Id: %d is Started\n", getpid());
    signal(SIGALRM, suspend);
    if ((pc1 = fork()) == 0)
    {
    	printf("Child 1 created with Id: %d\n",getpid());
        while (1);
    }
    else
    {
        if ((pc2 = fork()) == 0)
        {
            printf("Child 2 created with Id: %d\n",getpid());
            while (1);
        }
        else
        {
            alarm(2);
            while (1);
        }
    }
}
