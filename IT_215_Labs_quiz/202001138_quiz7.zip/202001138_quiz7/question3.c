#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void handler1() {printf("\nHandler1 is exeucted by %d\n", getpid());}
void handler2() {printf("\nHandler2 is exeucted by %d\n", getpid());}
void main()
{
    signal(SIGINT, handler1);
    if (fork() == 0) signal(SIGINT, handler2);
    while(1);
}
