#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>


#define READ 0
#define WRITE 1


static void signal_handler(int);
int i, pid1, pid2, status;

int byteread;
int fd1[2],status;
char msg[256];


int main()
{
    char buffer[256];
    int exit_status;
    pipe(fd1); /* pipe for parent to child */
    FILE* file=fopen("file1.txt","r");
    FILE* file2=fopen("file2.txt","r");
    if( signal( SIGUSR1, signal_handler) == SIG_ERR  )
    {
        printf("P�rent: Unable to create handler for SIGUSR1\n");
    }

    if( signal( SIGUSR2, signal_handler) == SIG_ERR  )
    {
        printf("P�rent: Unable to create handler for SIGUSR2\n");
    }

    pid1=getpid();
    printf("I am Parent process with Id: %d\n",pid1);
    pid2 = fork();
    if( pid2 == 0 )
    {
    	while(fgets(buffer,sizeof(buffer),file2))
    	{
    		kill(pid1,SIGUSR1);
		write(fd1[WRITE],buffer,strlen(buffer)+1);
		pause();
    	}
    	fclose(file2);
    }
    else
    { 
    	printf("I am Child process with Id: %d\n\n",pid2);
    	while(fgets(buffer,sizeof(buffer),file))
    	{
    		kill(pid2,SIGUSR1);
		write(fd1[WRITE],buffer,strlen(buffer)+1);
		pause();
    	}
    	fclose(file);
    	wait(&status);
    }

    return 0;
}

static void signal_handler(int signo)
{

    /* signo contains the signal number that was received */
    switch( signo )
    {
        /* Signal is a SIGUSR1 */
        case SIGUSR1:
            	printf( "Process (%d): received SIGUSR1 to recieve data\n", getpid());
            	if(pid1==getpid()) /* it is the parent */
		{
			byteread=read(fd1[READ],msg,256);
                	printf("File2: %s",msg);
			kill(pid2, SIGUSR2);
		}
		else /* it is the child */
		{
                	byteread=read(fd1[READ],msg,256);
                	printf("File1: %s",msg);
			kill(pid1, SIGUSR2);
		}
            	break;
        
        /*  It's a SIGUSR2 */
        case SIGUSR2:
            	printf( "Process (%d): received SIGUSR2 as acknowledgement\n", getpid() );
            	if(pid1==getpid())
		{
              		printf("Transmission from parent to child is completed.\n\n");
		}
		else
		{
			printf("Transmission from child to parent is completed.\n\n");
		}
            	break;
        default:
		break;
    }

    return;
}
