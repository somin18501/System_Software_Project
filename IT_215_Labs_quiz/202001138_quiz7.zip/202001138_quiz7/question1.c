#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<signal.h>


void signalHandler(){
	printf("\nctrl+c Recieved by handler\n");
}


int main(){
	//way1
	signal(SIGINT, SIG_IGN); /* Ignore Control-C */
	printf("Press ctrl+c!\n");
	sleep(3);
	
	printf("\nctrl+c Ignored for 3sec\n");
	//way2
	signal(SIGINT,signalHandler);
	printf("Press ctrl+c again!\n");
	sleep(3);
	printf("ctrl+c Ignored again for 3sec\n");
	
	signal(SIGINT,SIG_DFL);
	sleep(3);
	printf("Press ctrl+c finally!\n");
	sleep(1000);
}
