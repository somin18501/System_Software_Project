#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>

struct query{
    int query_id;
    char *query_txt;
    int status;
    float time_elapsed;
};

void add_new_entry(struct query *tp,int n){
    int fg=0;
    for(int i=0;i<n;i++){
        if(tp[i].query_id==-1){
            char qry_txt[100];
            printf("enter query name: ");
            scanf("%s",&qry_txt);
            tp[i].query_id=20220000+i;
            strcpy(tp[i].query_txt,qry_txt);
            fg=1;
            break;
        }
    }
    if(fg==0) printf("Sorry!, query table exhausted\n");
}

void start_query(struct query *tp,int qid,int n){
    if(qid-20220000<n && tp[qid-20220000].query_id!=-1){
        if(tp[qid-20220000].status==-1){
            tp[qid-20220000].status=0;
            tp[qid-20220000].time_elapsed=clock();
        }
        else printf("query is already started or finished\n");
    } 
    else printf("NO such query id exist\n");
}

void update_time(struct query *tp,int qid,int n){
    if(qid-20220000<n && tp[qid-20220000].query_id!=-1){
        if(tp[qid-20220000].status==0){
            printf("time since query is started is: %f micro secs\n",clock()-tp[qid-20220000].time_elapsed);
            tp[qid-20220000].time_elapsed=clock();
        }
        else if(tp[qid-20220000].status==1){
            printf("time since query is finished is: %f micro secs\n",clock()-tp[qid-20220000].time_elapsed);
        }
        else{
            printf("query is not yet started\n");
        }
    } 
    else printf("NO such query id exist\n");
}

void finish_query(struct query *tp,int qid,int n){
    if(qid-20220000<n && tp[qid-20220000].query_id!=-1){
        if(tp[qid-20220000].status==0){
            tp[qid-20220000].status=1;
            tp[qid-20220000].time_elapsed=clock();
        }
        else printf("query is already finished or not started\n");
    } 
    else printf("NO such query id exist\n");
}

void Remove(struct query *tp,int n){
    for(int i=0;i<n;i++){
        if(tp[i].query_id!=-1 && tp[i].status==1){
            tp[i].query_id=-1;
            tp[i].status=-1;
            tp[i].time_elapsed=0;
        }
    }
}

void printtable(struct query *tp,int n){
    for(int i=0;i<n;i++){
        if(tp[i].query_id!=-1){
            printf("query_id: %d\n",tp[i].query_id);
            printf("query name: %s\n",tp[i].query_txt);
            if(tp[i].status==-1) printf("status: submitted\n");
            else if(tp[i].status==0) printf("status: running\n");
            else printf("status: completed\n");
            printf("time_elapsed: %f micro secs\n",tp[i].time_elapsed);
            printf("\n");
        }
    }
}

int main(){
    int n;
    printf("Enter the total no. of queries: ");
    scanf("%d",&n);
    struct query *db=(struct query *)malloc(n*sizeof(struct query));
    for(int i=0;i<n;i++){
        db[i].query_id=-1;
        db[i].status=-1;
        db[i].time_elapsed=0;
        db[i].query_txt=(char *)malloc(100*sizeof(char));
    }
    while(1){
        int option,qid;
        printf("Enter 1 to add new query               Enter 2 to start query                    Enter 3 to update time elapsed\n");
        // printf("Enter 2 to start query\n");
        // printf("Enter 3 to update time elapsed\n");
        printf("Enter 4 to finish the query            Enter 5 to remove the query               Enter 6 to view all queries\n");
        // printf("Enter 5 to remove the query\n");
        // printf("Enter 6 to view all queries\n");
        printf("Enter 0 to exit\n");
        printf("Enter the option no. from below list to modify queries: ");
        scanf("%d",&option);
        switch (option){
        case 1:
            printf("\n");
            add_new_entry(db,n);
            printf("\n");
            printtable(db,n);
            break;
        case 2:
            printf("Enter query id that is to be started: ");
            scanf("%d",&qid);
            printf("\n");
            start_query(db,qid,n);
            printf("\n");
            printtable(db,n);
            break;
        case 3:
            printf("Enter query id whose time is to be updated: ");
            scanf("%d",&qid);
            printf("\n");
            update_time(db,qid,n);
            printf("\n");
            printtable(db,n);
            break;
        case 4:
            printf("Enter query id that is to be finished: ");
            scanf("%d",&qid);
            printf("\n");
            finish_query(db,qid,n);
            printf("\n");
            printtable(db,n);
            break;
        case 5:
            Remove(db,n);
            printf("\n");
            printtable(db,n);
            break;
        case 6:
            printf("\n");
            printtable(db,n);
            break;
        case 0:
            printf("You are exited\n");
            break;
        default:
            printf("INVALID OPTION\n");
            break;
        }
        if(option==0) break;
    }
    return 0;
}