#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>

struct query{
    int query_id;
    char *query_txt;
    int status;
    float time_elapsed;
    struct query *next;
};

struct query *head = NULL;
struct query *last = NULL;

void add_new_entry(){
    static int id=0;
    struct query *tmp=(struct query *)malloc(sizeof(struct query));
    tmp->query_id=20220000+id;
    tmp->status=-1;
    tmp->time_elapsed=0;
    tmp->next=NULL;
    tmp->query_txt=(char *)malloc(100*sizeof(char));
    char qry_txt[100];
    printf("enter query name: ");
    scanf("%s",&qry_txt);
    strcpy(tmp->query_txt,qry_txt);
    id++;
    if(head==NULL){
        head=tmp;
        last=tmp;
    }
    else{
        last->next=tmp;
        last=tmp;
    }
}

void start_query(int qid){
    struct query *n1;
    n1=head;
    while(n1){
        if(n1->query_id==qid){
            if(n1->status==-1){
                n1->status=0;
                n1->time_elapsed=clock();
            }
            else printf("query is already started or finished\n");
            break;
        }
        n1=n1->next;
    }
    if(n1==NULL) printf("NO such query id exist\n");
}

void update_time(int qid){
    struct query *n1;
    n1=head;
    while(n1){
        if(n1->query_id==qid){
            if(n1->status==0){
                printf("time since query is started is: %f micro secs\n",clock()-n1->time_elapsed);
                n1->time_elapsed=clock();
            }
            else if(n1->status==1){
                printf("time since query is finished is: %f micro secs\n",clock()-n1->time_elapsed);
            }
            else{
                printf("query is not yet started\n");
            }
            break;
        }
        n1=n1->next;
    } 
    if(n1==NULL) printf("NO such query id exist\n");
}

void finish_query(int qid){
    struct query *n1;
    n1=head;
    while(n1){
        if(n1->query_id==qid){
            if(n1->status==0){
                n1->status=1;
                n1->time_elapsed=clock();
            }
            else printf("query is already finished or not started\n");
            break;
        }
        n1=n1->next;
    }
    if(n1==NULL) printf("NO such query id exist\n");
}

void Remove(){
    if(head!=NULL){
        if(head->status==1) head=head->next;
        else{
            struct query *n1,*n2;
            n1=head;
            n2=n1->next;
            while(n2){
                if(n2->status==1){
                    n1->next=n2->next;
                    n2=n1->next;
                    if(n2==NULL){
                        last=n1;
                    }
                }
                else{
                    n1=n1->next;
                    n2=n2->next;
                }
            }
        }
    }
    else{
        printf("query table is empty\n");
    }
}

void printtable(){
    struct query *n1;
    n1=head;
    while(n1){
        printf("query_id: %d\n",n1->query_id);
        printf("query name: %s\n",n1->query_txt);
        if(n1->status==-1) printf("status: submitted\n");
        else if(n1->status==0) printf("status: running\n");
        else printf("status: completed\n");
        printf("time_elapsed: %f micro secs\n",n1->time_elapsed);
        printf("\n");
        n1=n1->next;
    }
}

int main(){
    while(1){
        int option,qid;
        printf("Enter 1 to add new query               Enter 2 to start query                    Enter 3 to update time elapsed\n");
        // printf("Enter 2 to start query\n");
        // printf("Enter 3 to update time elapsed\n");
        printf("Enter 4 to finish the query            Enter 5 to remove the query               Enter 6 to view all queries\n");
        // printf("Enter 5 to remove the query\n");
        // printf("Enter 6 to view all queries\n");
        printf("Enter 0 to exit\n");
        printf("Enter the option no. from below list to modify queries: ");
        scanf("%d",&option);
        switch (option){
        case 1:
            add_new_entry();
            printf("\n");
            printtable();
            break;
        case 2:
            printf("Enter query id that is to be started: ");
            scanf("%d",&qid);
            printf("\n");
            start_query(qid);
            printf("\n");
            printtable();
            break;
        case 3:
            printf("Enter query id whose time is to be updated: ");
            scanf("%d",&qid);
            printf("\n");
            update_time(qid);
            printf("\n");
            printtable();
            break;
        case 4:
            printf("Enter query id that is to be finished: ");
            scanf("%d",&qid);
            printf("\n");
            finish_query(qid);
            printf("\n");
            printtable();
            break;
        case 5:
            printf("\n");
            Remove();
            printf("\n");
            printtable();
            break;
        case 6:
            printf("\n");
            printtable();
            break;
        case 0:
            printf("You are exited\n");
            break;
        default:
            printf("INVALID OPTION\n");
            break;
        }
        if(option==0) break;
    }
    return 0;
}