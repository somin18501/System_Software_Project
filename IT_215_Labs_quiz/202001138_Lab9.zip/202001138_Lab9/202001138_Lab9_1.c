#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <math.h>

double sroot[100];

void *srot(void *arg)
{
	int *ptr = arg;
    for(int k=*ptr;k<(*ptr+10);k++){
        sroot[k]=sqrt(sroot[k]);
    }
}

int main( int argc, char* argv[] )
{
	printf("the main thread %ld has started\n", pthread_self());
    for(int j=0;j<100;j++){
        sroot[j]=(double)j;
    }
	int i;
	pthread_t threadID[10];
    int arr[100];
    for(int i=0;i<100;i+=10){
        arr[i]=i;
    }
	for(i=0; i<100; i=i+10)
	{	
		int err = pthread_create (&threadID[i/10], NULL, srot, (void *)&arr[i]);
        if (err != 0)
            printf("cant create thread: %s\n", strerror(err));
		printf("Thread with threadID %ld is created\n",threadID[i/10]);
	}
    for(int k=0;k<100;k=k+10){
		pthread_join(threadID[k/10], NULL); 
        printf("The thread with threadID %ld is terminated\n",threadID[k/10]);
    }
    printf("square root of numbers 0-99 is:\n");
    for(int j=0;j<100;j++){
        if(j!=0 && j%10==0) printf("\n");
        printf("%lf ",sroot[j]);
    }
	printf("\nthe main thread %ld has terminated\n", pthread_self());
}