#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <inttypes.h>

uint64_t get_gtod_clock_time ()
{
    struct timeval tv;
    if (gettimeofday (&tv, NULL) == 0)
        return (uint64_t) (tv.tv_sec * 1000000 + tv.tv_usec);
    else
        return 0;
}

#define ROW 5000
#define COL 5000
int mat[ROW][COL];

struct params
{
	int num1;
	int num2;
};

void *matrixsum(void *arg)
{
	struct params *thread_p = (struct params *)arg;
	long long *sum=(long long*)malloc(sizeof(long long));
    for(int i=thread_p->num1;i<(thread_p->num1+thread_p->num2);i++){
        for(int j=0;j<COL;j++){
            *sum+=mat[i][j];
        }
    }
    pthread_exit((void*)sum);
}

int main( int argc, char* argv[] )
{
    for(int i=0;i<ROW;i++){
        for(int j=0;j<COL;j++){
            mat[i][j]=rand()%100;
            // printf("%d ",mat[i][j]);
        }
        // printf("\n");
    }

    uint64_t start_time_value, end_time_value, time_diff;

    int num_thread;
    printf("Enter number of threads to be created: ");
    scanf("%d",&num_thread);
    int k=(num_thread<ROW)?num_thread:ROW;
    int l=0,j=ROW/k,rem=ROW%k;
    long long fsum1=0,fsum2=0;
    pthread_t threadID[k];
    struct params p[k];
    for(int i=0;i<k;i++){
        p[i].num1 = l;
        if(rem){
            p[i].num2 = j+1;
            l+=(j+1);
            rem--;
        }
        else{
            p[i].num2 = j;
            l+=j;
        }
    }

    start_time_value = get_gtod_clock_time();
    
        for(int i=0;i<k;i++){
            int err = pthread_create (&threadID[i], NULL, matrixsum, (void *)&p[i]);
            if (err != 0)
                printf("cant create thread: %s\n", strerror(err));
        }
        for(int j=0;j<k;j++){
            int *retval;
            pthread_join(threadID[j], (void **)&retval);
            fsum1+=(int)*retval;
            free(retval);
        }
        printf("the sum of entire matrix in parallel algo is: %lld\n",fsum1);

    end_time_value = get_gtod_clock_time();
    time_diff = end_time_value - start_time_value;
    printf("Time of parallel algo %" PRIu64 "\n", time_diff);

    start_time_value = get_gtod_clock_time();

        for(int i=0;i<ROW;i++){
            for(int j=0;j<COL;j++){
                fsum2+=mat[i][j];
            }
        }
        printf("the sum of entire matrix in serial algo is: %lld\n",fsum2);

    end_time_value = get_gtod_clock_time();
    time_diff = end_time_value - start_time_value;
    printf("Time of serial algo %" PRIu64 "\n", time_diff);
    return 0;
}